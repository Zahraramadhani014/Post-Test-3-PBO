// Post Test 3 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest3pbo.service;

import com.mycompany.posttest3pbo.model.Transaksi;
import com.mycompany.posttest3pbo.model.Pemasukan;
import com.mycompany.posttest3pbo.model.Pengeluaran;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class TransaksiService {

    private final List<Transaksi> daftar = new ArrayList<>();
    private final Scanner input = new Scanner(System.in);
    private int autoId = 1;
    private double batasPengeluaranBulanan = 0;

    // Data Awal
    public void seed() {
        tambahSeed("2025-09-01", "Gaji Bulanan", "Pemasukan", "Gaji", "Transfer", 5_000_000);
        tambahSeed("2025-09-02", "Beli Makan Siang", "Pengeluaran", "Makan", "Cash", 25_000);
        tambahSeed("2025-09-03", "Ongkos Transportasi", "Pengeluaran", "Transportasi", "Cash", 10_000);
        tambahSeed("2025-09-04", "Nonton Bioskop", "Pengeluaran", "Hiburan", "E-Wallet", 50_000);
        tambahSeed("2025-09-05", "Beli Pakaian", "Pengeluaran", "Belanja", "Transfer", 200_000);
        tambahSeed("2025-09-06", "Menabung Rutin", "Pemasukan", "Tabungan", "Transfer", 500_000);
        tambahSeed("2025-09-07", "Bayar Listrik", "Pengeluaran", "Tagihan", "E-Wallet", 150_000);
        tambahSeed("2025-09-08", "Bayar Air", "Pengeluaran", "Tagihan", "Transfer", 100_000);
        tambahSeed("2025-09-09", "Isi Saldo Tabungan", "Pemasukan", "Tabungan", "Transfer", 300_000);
        tambahSeed("2025-09-10", "Makan Malam di Restoran", "Pengeluaran", "Makan", "Cash", 75_000);
        tambahSeed("2025-09-10", "Bonus Proyek Mega", "Pemasukan", "Gaji", "Transfer", 500_000);
        tambahSeed("2025-09-11", "Beli Bensin 1 Liter", "Pengeluaran", "Transportasi", "Cash", 50_000);
    }

    private void tambahSeed(String tgl, String ket, String jenis, String kat, String metode, double jml) {
        if ("Pemasukan".equalsIgnoreCase(jenis)) {
            daftar.add(new Pemasukan(autoId++, tgl, ket, kat, metode, jml));
        } else {
            daftar.add(new Pengeluaran(autoId++, tgl, ket, kat, metode, jml));
        }
    }

    // Menu CRUD
    // Tambah Catatan
    public void tambahCatatan() {
        String ulang;
        do {
            header("TAMBAH CATATAN KEUANGAN");

            String tanggal = inputTanggalWajib("-> Silakan Input Tanggal (Format yyyy-mm-dd): ");
            String keterangan = inputWajib("-> Silakan Input Keterangannya : ");
            String jenis = inputPilihanWajib(
                "-> Silakan Input Jenis Transaksinya (Pemasukan/Pengeluaran): ",
                new String[]{"Pemasukan", "Pengeluaran"}
            );
            String kategori = inputPilihanWajib(
                "-> Silakan Input Kategori (gaji, makan, transportasi, hiburan, belanja, tabungan, tagihan): ",
                new String[]{"Gaji", "Makan", "Transportasi", "Hiburan", "Belanja", "Tabungan", "Tagihan"}
            );
            String metode = inputPilihanWajib(
                "-> Silakan Input Metode Pembayaran (Cash/E-Wallet/Transfer): ",
                new String[]{"Cash", "E-Wallet", "Transfer"}
            );
            double jumlah = inputDoubleWajib("-> Silakan Input Nominal Transaksinya : ");

            if ("Pemasukan".equalsIgnoreCase(jenis)) {
                daftar.add(new Pemasukan(autoId++, tanggal, keterangan, kategori, metode, jumlah));
            } else {
                daftar.add(new Pengeluaran(autoId++, tanggal, keterangan, kategori, metode, jumlah));
            }
            System.out.println("\nData berhasil ditambahkan");

            // Peringatan batas bulanan
            if (batasPengeluaranBulanan > 0) {
                double totalKeluar = hitungTotalJenis("Pengeluaran");
                if (totalKeluar > batasPengeluaranBulanan) {
                    System.out.println(
                        "\nPeringatan: Pengeluaran melebihi batas bulanan (" +
                        formatRupiah(batasPengeluaranBulanan) + "). Total saat ini: " +
                        formatRupiah(totalKeluar)
                    );
                }
            }

            tampilkanTabel(daftar);

            System.out.print("\nApakah ingin menambah catatan lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }
    
    // Lihat Catatan
    public void lihatSemuaCatatan() {
        tampilkanTabel(daftar);
    }
    
    // Ubah Catatan
    public void ubahCatatan() {
        String ulang;
        do {
            header("UBAH CATATAN KEUANGAN");
            tampilkanTabel(daftar);
            System.out.print("-> Masukkan ID Yang Ingin Diubah: ");
            int id = safeNextInt();

            Transaksi t = findById(id);
            if (t == null) {
                System.out.println("\nID tidak ditemukan");
            } else {
                t.setTanggal(inputStringOpsional("-> Input Tanggal baru (yyyy-mm-dd): ", t.getTanggal()));
                t.setKeterangan(inputStringOpsional("-> Input Keterangan baru: ", t.getKeterangan()));
                t.setJenis(inputStringOpsional("-> Input Jenis baru (Pemasukan/Pengeluaran): ", t.getJenis())); 
                t.setKategori(inputStringOpsional("-> Input Kategori baru: ", t.getKategori()));
                t.setMetodePembayaran(inputStringOpsional("-> Input Metode Pembayaran baru: ", t.getMetodePembayaran()));
                t.setJumlah(inputDoubleOpsional("-> Input Nominal Transaksi baru: ", t.getJumlah()));
                System.out.println("\nData berhasil diubah");
            }

            tampilkanTabel(daftar);
            System.out.print("\nApakah ingin mengubah catatan lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }
    
    // Hapus Catatan
    public void hapusCatatan() {
        String ulang;
        do {
            header("HAPUS CATATAN KEUANGAN");
            tampilkanTabel(daftar);
            Integer id = inputIntAtauBatal("-> Masukkan ID yang ingin dihapus (Enter=batalkan): ");
            if (id == null) {
                System.out.println("\nPenghapusan dibatalkan");
                return;
            }

            Transaksi t = findById(id);
            if (t == null) {
                System.out.println("\nID tidak ditemukan");
            } else {
                System.out.print("Apakah Anda yakin ingin menghapus ID " + id + " ? (Y/T): ");
                String ya = input.nextLine().trim().toLowerCase();
                if (ya.equals("y")) {
                    daftar.remove(t);
                    System.out.println("\nData berhasil dihapus");
                } else {
                    System.out.println("\nPenghapusan dibatalkan");
                }
            }
            System.out.print("\nApakah ingin menghapus catatan lagi? (Y/T): ");
            ulang = input.nextLine();
            System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }
    
    // Ringkasan Saldo
    public void ringkasanSaldo() {
        double totalMasuk = hitungTotalJenis("Pemasukan");
        double totalKeluar = hitungTotalJenis("Pengeluaran");

        header("RINGKASAN SALDO");
        System.out.println("Total Pemasukan   : " + formatRupiah(totalMasuk));
        System.out.println("Total Pengeluaran : " + formatRupiah(totalKeluar));
        System.out.println("Saldo             : " + formatRupiah(totalMasuk - totalKeluar));
        System.out.println("================================================================================");

        if (totalKeluar > totalMasuk) {
            System.out.println("\nCatatan: Pengeluaran lebih besar dari pemasukan. Harap bijak mengatur keuangan\n");
        }
        tungguKembali();
    }
    
    // Set Batas Pengeluaran Bulanan
    public void setBatasPengeluaran() {
        header("SET BATAS PENGELUARAN BULANAN");
        System.out.println("Batas saat ini : " + (batasPengeluaranBulanan <= 0
                ? "— (tidak diaktifkan)" : formatRupiah(batasPengeluaranBulanan)));

        double val = inputDoubleNonNegatif("-> Masukkan batas baru (ketik 0 untuk menonaktifkan): ");
        batasPengeluaranBulanan = val;

        if (batasPengeluaranBulanan == 0) {
            System.out.println("\nBatas pengeluaran bulanan dinonaktifkan");
        } else {
            System.out.println("\nBatas disetel: " + formatRupiah(batasPengeluaranBulanan));
            double totalKeluar = hitungTotalJenis("Pengeluaran");
            double sisa = batasPengeluaranBulanan - totalKeluar;
            System.out.println("Total pengeluaran saat ini: " + formatRupiah(totalKeluar));
            System.out.println("Sisa ruang anggaran       : " + formatRupiah(sisa));
            if (sisa < 0) {
                System.out.println("Peringatan: Pengeluaran sudah melebihi batas !!!");
            }
        }
        tungguKembali();
    }

    // Menu Filter dan Search
    public void menuFilter() {
        int pilih;
        do {
            System.out.println("\n===========================================================================");
            System.out.println("|                             MENU FILTER/SEARCH                          |");
            System.out.println("===========================================================================");
            System.out.println("| 1. Filter per Jenis (Pemasukan/Pengeluaran)                             |");
            System.out.println("| 2. Filter per Kategori                                                  |");
            System.out.println("| 3. Filter per Metode Pembayaran                                         |");
            System.out.println("| 4. Search (cari di keterangan)                                          |");
            System.out.println("| 5. Kembali                                                              |");
            System.out.println("=========================================================================== ");
            System.out.print("Pilih [1-5]: ");
            pilih = safeNextInt();

            switch (pilih) {
                case 1 -> filterByJenis();
                case 2 -> filterByKategori();
                case 3 -> filterByMetode();
                case 4 -> searchByKeterangan();
                case 5 -> System.out.println();
                default -> System.out.println("Pilihan tidak valid\n");
            }
        } while (pilih != 5);
    }

    private void filterByJenis() {
        System.out.println("\n=================================================================================");
        System.out.println("|                            Filter berdasarkan Jenis                           |");
        System.out.println("=================================================================================");
        String j = inputPilihanWajib("-> Masukkan Jenis (Pemasukan/Pengeluaran): ",
                new String[]{"Pemasukan", "Pengeluaran"});
        List<Transaksi> hasil = daftar.stream()
                .filter(t -> t.getJenis().equalsIgnoreCase(j))
                .collect(Collectors.toList());
        tampilkanAtauKosong(hasil, "jenis tersebut");
    }

    private void filterByKategori() {
        System.out.println("\n=================================================================================");
        System.out.println("|                           Filter berdasarkan Kategori                         |");
        System.out.println("=================================================================================");
        String k = inputPilihanWajib(
                "-> Masukkan Kategori (gaji, makan, transportasi, hiburan, belanja, tabungan, tagihan): ",
                new String[]{"Gaji", "Makan", "Transportasi", "Hiburan", "Belanja", "Tabungan", "Tagihan"}
        );
        List<Transaksi> hasil = daftar.stream()
                .filter(t -> t.getKategori().equalsIgnoreCase(k))
                .collect(Collectors.toList());
        tampilkanAtauKosong(hasil, "kategori tersebut");
    }

    private void filterByMetode() {
        System.out.println("\n=================================================================================");
        System.out.println("|                       Filter berdasarkan Metode Pembayaran                    |");
        System.out.println("=================================================================================");
        String m = inputPilihanWajib("-> Masukkan Metode (Cash/E-Wallet/Transfer): ",
                new String[]{"Cash", "E-Wallet", "Transfer"});
        List<Transaksi> hasil = daftar.stream()
                .filter(t -> t.getMetodePembayaran().equalsIgnoreCase(m))
                .collect(Collectors.toList());
        tampilkanAtauKosong(hasil, "metode tersebut");
    }

    private void searchByKeterangan() {
        System.out.println("\n=================================================================================");
        System.out.println("|                                SEARCH KETERANGAN                              |");
        System.out.println("=================================================================================");
        String q = inputWajib("-> Kata kunci: ").toLowerCase();
        List<Transaksi> hasil = daftar.stream()
                .filter(t -> t.getKeterangan().toLowerCase().contains(q))
                .collect(Collectors.toList());
        tampilkanAtauKosong(hasil, "hasil pencarian");
    }

    private void tampilkanAtauKosong(List<Transaksi> data, String labelKosong) {
        if (data.isEmpty()) {
            System.out.println("\nTidak ada data dengan " + labelKosong + ".");
            tungguKembali();
        } else {
            tampilkanTabel(data);
        }
    }

    //  Utilitas
    public void tampilkanTabel(List<Transaksi> data) {
        int[] w = {4, 12, 12, 15, 12, 15, 30};
        System.out.println();
        System.out.println(garis(w));
        System.out.printf(
                "| %-" + w[0] + "s | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                "ID", "Tanggal", "Jenis", "Kategori", "Metode", "Jumlah", "Keterangan"
        );
        System.out.println(garis(w));

        if (data.isEmpty()) {
            System.out.printf("| %-" + (w[0] + w[1] + w[2] + w[3] + w[4] + w[5] + w[6] + 18) + "s |\n", "Belum ada data transaksi");
        } else {
            for (Transaksi t : data) {
                String jumlahStr = formatRupiah(t.getJumlah());
                String ket = t.getKeterangan().length() > w[6]
                        ? t.getKeterangan().substring(0, w[6] - 3) + "..."
                        : t.getKeterangan();
                System.out.printf(
                        "| %-" + w[0] + "d | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                        t.getId(), t.getTanggal(), t.getJenis(), t.getKategori(), t.getMetodePembayaran(), jumlahStr, ket
                );
            }
        }
        System.out.println(garis(w));
        tungguKembali();
    }

    private String garis(int[] widths) {
        StringBuilder sb = new StringBuilder();
        sb.append('+');
        for (int w : widths) {
            for (int i = 0; i < w + 2; i++) {
                sb.append('-');
            }
            sb.append('+');
        }
        return sb.toString();
    }

    private double hitungTotalJenis(String jenis) {
        return daftar.stream()
                .filter(t -> t.getJenis().equalsIgnoreCase(jenis))
                .mapToDouble(Transaksi::getJumlah)
                .sum();
    }

    private String formatRupiah(double nilai) {
        String s = String.format("%,.0f", nilai).replace(',', '.');
        return "Rp " + s;
    }

    private Transaksi findById(int id) {
        for (Transaksi t : daftar) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    // Validasi dan Input Helpers
    private final Pattern TANGGAL = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    private String inputWajib(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = input.nextLine().trim();
            if (!v.isEmpty()) {
                return v;
            }
            System.out.println("Tidak boleh kosong. Coba lagi");
        }
    }

    private String inputTanggalWajib(String prompt) {
        while (true) {
            String v = inputWajib(prompt);
            if (TANGGAL.matcher(v).matches()) {
                return v;
            }
            System.out.println("Format tanggal harus yyyy-mm-dd");
        }
    }

    private String inputPilihanWajib(String prompt, String[] allowed) {
        while (true) {
            String v = inputWajib(prompt);
            for (String a : allowed) {
                if (a.equalsIgnoreCase(v)) {
                    return a; 
                }
            }
            System.out.println("Pilihan tidak valid. Pilihan yang valid: " + String.join("/", allowed));
        }
    }

    private double inputDoubleWajib(String prompt) {
        while (true) {
            System.out.print(prompt);
            String v = input.nextLine().trim();
            if (v.isEmpty()) {
                System.out.println("Tidak boleh kosong. Coba lagi");
                continue;
            }
            try {
                return Double.parseDouble(v);
            } catch (NumberFormatException e) {
                System.out.println("Harus angka. Coba lagi");
            }
        }
    }

    // menu untuk ubah (Enter = pertahankan)
    private String inputStringOpsional(String prompt, String nilaiLama) {
        System.out.print(prompt);
        String v = input.nextLine();
        return v.isEmpty() ? nilaiLama : v;
    }

    private double inputDoubleOpsional(String prompt, double nilaiLama) {
        System.out.print(prompt);
        while (true) {
            String v = input.nextLine().trim();
            if (v.isEmpty()) {
                return nilaiLama;
            }
            try {
                return Double.parseDouble(v);
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Ulangi: ");
            }
        }
    }

    private int safeNextInt() {
        while (true) {
            try {
                return Integer.parseInt(input.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Silakan input ulang: ");
            }
        }
    }

    private double safeNextDouble() {
        while (true) {
            try {
                return Double.parseDouble(input.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Harus angka! Silakan input ulang: ");
            }
        }
    }

    private void tungguKembali() {
        int k;
        do {
            System.out.print("-> Ketik 0 untuk kembali: ");
            k = safeNextInt();
        } while (k != 0);
        System.out.println();
    }

    //  Header
    private void header(String title) {
        System.out.println("\n=================================================================================");
        System.out.println(center(title, 81));
        System.out.println("=================================================================================");
    }

    private String center(String text, int width) {
        if (text.length() >= width) {
            return text;
        }
        int pad = (width - text.length()) / 2;
        return " ".repeat(pad) + text;
    }

    // Input Opsional: Enter = batal 
    private Integer inputIntAtauBatal(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = input.nextLine().trim();
            if (s.isEmpty()) {
                return null;
            }
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("Harus angka! Coba lagi");
            }
        }
    }

    private Double inputDoubleAtauBatal(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = input.nextLine().trim();
            if (s.isEmpty()) {
                return null;
            }
            try {
                return Double.parseDouble(s);
            } catch (NumberFormatException e) {
                System.out.println("Harus angka! Coba lagi");
            }
        }
    }

    // Helper untuk batas pengeluaran
    private double inputDoubleNonNegatif(String prompt) {
        while (true) {
            double d = inputDoubleWajib(prompt);
            if (d < 0) {
                System.out.println("Tidak boleh negatif. Coba lagi");
            } else {
                return d;
            }
        }
    }
}

